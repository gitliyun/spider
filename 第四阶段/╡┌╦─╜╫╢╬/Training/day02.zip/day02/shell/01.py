#!/usr/bin/env python3

import sys

if len(sys.argv) == 3:
    print(sys.argv[1]+sys.argv[2])
else:
    print('参数错误')
