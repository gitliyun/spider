#!/bin/bash

read -p 请输入姓名: name
read -p 请输入成绩: score

echo "$name的成绩为:$score分"
