#!/bin/bash

for i in `seq 1 2 10`
do
    echo $i
done
