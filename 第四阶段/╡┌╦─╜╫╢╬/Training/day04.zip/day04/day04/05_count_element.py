my_list = [1,2,3,4,5,1,2,1,2]
my_set = set(my_list)

for item in my_set:
    print('{}出现了{}次'.format(item,my_list.count(item)))












